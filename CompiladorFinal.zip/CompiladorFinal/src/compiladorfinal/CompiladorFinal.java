package compiladorfinal;

/**
 *
 * @author MrCante
 */
public class CompiladorFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Principal mostrar = new Principal();
        mostrar.show();
        
    }
    
}
